import { useEffect, useRef, useState, useCallback } from 'react'
import { getCameraStreamUrl } from '../services/api'
import { WifiOff, Maximize2 } from 'lucide-react'

export default function CameraFeed({
  cameraId,
  name    = `Camera ${cameraId}`,
  width   = 480,
  height  = 360,
  onClick,
}) {
  const canvasRef  = useRef(null)
  const wsRef      = useRef(null)
  const prevUrlRef = useRef(null)
  const rafRef     = useRef(null)
  const fpsRef     = useRef({ frames: 0, last: Date.now() })

  const [status, setStatus] = useState('connecting')
  const [fps, setFps] = useState(0)

  // ── Draw frame ──────────────────────────────────────
  const drawFrame = useCallback((blobUrl) => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current)

    rafRef.current = requestAnimationFrame(() => {
      const canvas = canvasRef.current
      if (!canvas) return

      const ctx = canvas.getContext('2d')
      const img = new Image()

      img.onload = () => {
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)

        if (prevUrlRef.current) {
          URL.revokeObjectURL(prevUrlRef.current)
        }

        prevUrlRef.current = blobUrl

        // FPS tracking
        const now = Date.now()
        fpsRef.current.frames++

        if (now - fpsRef.current.last >= 1000) {
          setFps(fpsRef.current.frames)
          fpsRef.current.frames = 0
          fpsRef.current.last = now
        }
      }

      img.onerror = () => {
        URL.revokeObjectURL(blobUrl)
      }

      img.src = blobUrl
    })
  }, [])

  // ── WebSocket connection ────────────────────────────
  useEffect(() => {
    let reconnectTimer = null
    let mounted = true

    function connect() {
      if (!mounted || wsRef.current) return

      setStatus('connecting')

      const url = getCameraStreamUrl(cameraId)
      const ws = new WebSocket(url)

      wsRef.current = ws
      ws.binaryType = 'blob'

      ws.onopen = () => {
        if (mounted) setStatus('streaming')
      }

      ws.onmessage = (e) => {
        if (!e.data || e.data.size === 0) return
        const blobUrl = URL.createObjectURL(e.data)
        drawFrame(blobUrl)
      }

      ws.onerror = () => {
        if (mounted) setStatus('offline')
      }

      ws.onclose = () => {
        wsRef.current = null

        if (mounted) {
          setStatus('offline')
          reconnectTimer = setTimeout(connect, 2000)
        }
      }
    }

    connect()

    return () => {
      mounted = false

      clearTimeout(reconnectTimer)

      if (rafRef.current) cancelAnimationFrame(rafRef.current)

      if (prevUrlRef.current) {
        URL.revokeObjectURL(prevUrlRef.current)
      }

      if (wsRef.current) {
        wsRef.current.onclose = null
        wsRef.current.close()
        wsRef.current = null
      }
    }
  }, [cameraId, drawFrame])

  // ── UI state ────────────────────────────────────────
  const borderColor = status === 'streaming' ? 'var(--teal)' : 'var(--border)'
  const statusDot   = { streaming: '● Live', connecting: '◌ Connecting', offline: '○ Offline' }[status]
  const statusColor = { streaming: 'var(--green)', connecting: 'var(--yellow)', offline: 'var(--red)' }[status]

  return (
    <div
      onClick={onClick}
      style={{
        position: 'relative',
        background: '#0a0a0a',
        borderRadius: 'var(--radius)',
        overflow: 'hidden',
        border: `1px solid ${borderColor}`,
        cursor: onClick ? 'pointer' : 'default',
        transition: 'border-color 0.2s',
      }}
    >
      {/* Canvas */}
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        style={{ display: 'block', width: '100%', aspectRatio: `${width}/${height}` }}
      />

      {/* Offline overlay */}
      {status === 'offline' && (
        <div style={{
          position:'absolute', inset:0,
          display:'flex', flexDirection:'column',
          alignItems:'center', justifyContent:'center',
          background:'rgba(0,0,0,0.75)', gap:10,
        }}>
          <WifiOff size={30} color="var(--red)" />
          <span style={{ fontSize:13, color:'var(--text-2)' }}>Camera {cameraId} offline</span>
          <span style={{ fontSize:11, color:'var(--text-3)' }}>Reconnecting…</span>
        </div>
      )}

      {/* Connecting overlay */}
      {status === 'connecting' && (
        <div style={{
          position:'absolute', inset:0,
          display:'flex', flexDirection:'column',
          alignItems:'center', justifyContent:'center',
          background:'rgba(0,0,0,0.6)', gap:10,
        }}>
          <div className="spinner" />
          <span style={{ fontSize:12, color:'var(--text-3)' }}>
            Connecting to Camera {cameraId}…
          </span>
        </div>
      )}

      {/* Top HUD */}
      <div style={{
        position:'absolute', top:0, left:0, right:0,
        padding:'6px 10px',
        background:'linear-gradient(to bottom,rgba(0,0,0,0.72),transparent)',
        display:'flex', alignItems:'center', justifyContent:'space-between',
        pointerEvents:'none',
      }}>
        <span style={{ fontSize:12, fontWeight:600, color:'#fff' }}>{name}</span>
        <span style={{ fontSize:11, color: statusColor }}>
          {statusDot}{status === 'streaming' ? `  ${fps} fps` : ''}
        </span>
      </div>

      {/* Expand icon */}
      {onClick && status === 'streaming' && (
        <div style={{
          position:'absolute', bottom:8, right:8,
          background:'rgba(0,0,0,0.5)',
          border:'1px solid rgba(255,255,255,0.15)',
          borderRadius:4, padding:'3px 5px',
          pointerEvents:'none',
        }}>
          <Maximize2 size={12} color="#fff" />
        </div>
      )}
    </div>
  )
}