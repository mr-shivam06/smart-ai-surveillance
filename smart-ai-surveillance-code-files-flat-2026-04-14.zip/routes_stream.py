import logging
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.responses import Response

from app.stream_bridge import STREAM_BRIDGE
from app.core.security import decode_token

logger = logging.getLogger("StreamRoutes")

router = APIRouter()


def _verify_ws_token(token: str) -> bool:
    """Verify JWT from WebSocket query param."""
    if not token:
        return False
    try:
        payload = decode_token(token)
        return bool(payload.get("sub"))
    except Exception as e:
        logger.debug(f"[Stream] Token decode error: {e}")
        return False


@router.websocket("/{camera_id}")
async def camera_stream(
    websocket: WebSocket,
    camera_id: int,
    token: str = Query(""),
):
    """
    Live JPEG frame stream for one camera.
    """

    # 🔴 Accept FIRST (important for proper WS handshake)
    await websocket.accept()

    # 🔴 Auth check AFTER accept (prevents upgrade failure issues)
    if not _verify_ws_token(token):
        logger.warning(f"[Stream] Unauthorized access → Camera {camera_id}")
        await websocket.close(code=4001)
        return

    logger.info(f"[Stream] Client connected → Camera {camera_id}")

    try:
        async for jpeg in STREAM_BRIDGE.subscribe(camera_id):
            try:
                if jpeg:
                    await websocket.send_bytes(jpeg)
                else:
                    # 🔁 send keepalive (empty frame)
                    await websocket.send_bytes(b"")
            except Exception as e:
                logger.debug(f"[Stream] Send error Cam{camera_id}: {e}")
                break

    except WebSocketDisconnect:
        logger.info(f"[Stream] Client disconnected ← Camera {camera_id}")

    except Exception as e:
        logger.error(f"[Stream] Cam{camera_id} fatal error: {e}")

    finally:
        logger.info(f"[Stream] Cleanup done for Camera {camera_id}")


@router.get("/{camera_id}/snapshot")
async def snapshot(
    camera_id: int,
    token: str = Query(""),
):
    if not _verify_ws_token(token):
        raise HTTPException(401, "Unauthorized")

    jpeg = STREAM_BRIDGE.get_latest(camera_id)
    if not jpeg:
        raise HTTPException(404, f"No frame available for camera {camera_id}")

    return Response(content=jpeg, media_type="image/jpeg")


@router.get("/active")
async def active_streams(token: str = Query("")):
    if not _verify_ws_token(token):
        raise HTTPException(401, "Unauthorized")

    return {
        "active_cameras": STREAM_BRIDGE.active_camera_ids()
    }