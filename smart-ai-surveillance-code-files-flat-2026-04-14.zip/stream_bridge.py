import asyncio
import threading
import time
from typing import Dict, Optional, Set
import numpy as np
import cv2


class CameraStreamBridge:
    _instance  = None
    _init_lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._init_lock:
                if cls._instance is None:
                    o = super().__new__(cls)
                    o._setup()
                    cls._instance = o
        return cls._instance

    def _setup(self):
        self._frames: Dict[int, Optional[bytes]] = {}
        self._timestamps: Dict[int, float] = {}
        self._events: Dict[int, Set[asyncio.Event]] = {}
        self._lock = threading.Lock()

    # ── Camera thread writes frames ─────────────────────
    def put_frame(self, camera_id: int, frame: np.ndarray):
        try:
            ok, buf = cv2.imencode(
                ".jpg", frame,
                [cv2.IMWRITE_JPEG_QUALITY, 75]
            )
            if not ok:
                return
            jpeg = buf.tobytes()
        except Exception:
            return

        with self._lock:
            self._frames[camera_id]     = jpeg
            self._timestamps[camera_id] = time.time()

            events = self._events.get(camera_id, set())
            for ev in list(events):
                try:
                    loop = getattr(ev, "_loop", None)
                    if loop:
                        loop.call_soon_threadsafe(ev.set)
                except Exception:
                    pass

    def get_latest(self, camera_id: int) -> Optional[bytes]:
        with self._lock:
            return self._frames.get(camera_id)

    def active_camera_ids(self) -> list:
        cutoff = time.time() - 5.0
        with self._lock:
            return [
                cid for cid, ts in self._timestamps.items()
                if ts > cutoff
            ]

    # ── WebSocket subscription ──────────────────────────
    async def subscribe(self, camera_id: int):
        loop = asyncio.get_event_loop()
        ev   = asyncio.Event()
        ev._loop = loop

        with self._lock:
            if camera_id not in self._events:
                self._events[camera_id] = set()
            self._events[camera_id].add(ev)

        try:
            # ✅ Send latest immediately (if exists)
            latest = self.get_latest(camera_id)
            if latest:
                yield latest

            while True:
                try:
                    await asyncio.wait_for(ev.wait(), timeout=3.0)
                except asyncio.TimeoutError:
                    # ✅ keep connection alive
                    yield b""
                    continue

                ev.clear()

                jpeg = self.get_latest(camera_id)

                if jpeg:
                    yield jpeg
                else:
                    # ✅ prevent silent disconnect
                    yield b""

        except Exception as e:
            print(f"[STREAM_BRIDGE] Error cam{camera_id}: {e}")

        finally:
            with self._lock:
                events = self._events.get(camera_id, set())
                events.discard(ev)

    def is_active(self, camera_id: int) -> bool:
        cutoff = time.time() - 5.0
        with self._lock:
            return self._timestamps.get(camera_id, 0) > cutoff


# ── Singleton instance ─────────────────────────────────
STREAM_BRIDGE = CameraStreamBridge()