import { useState, useEffect } from 'react'
import { cameraAPI } from '../services/api'
import CameraFeed from '../components/CameraFeed'

export default function CamerasPage() {
  const [cameras, setCameras] = useState([])
  const [loading, setLoading] = useState(true)
  const [adding, setAdding] = useState(false)
  const [form, setForm] = useState({ name: '', source: '' })

  // ✅ Load once (correct)
  useEffect(() => {
    cameraAPI.list()
      .then(res => setCameras(res.data))
      .catch(err => console.error(err))
      .finally(() => setLoading(false))
  }, [])

  // ✅ Add camera safely
  const addCamera = async (e) => {
    e.preventDefault()
    setAdding(true)

    try {
      await cameraAPI.add(form)
      setForm({ name: '', source: '' })

      const res = await cameraAPI.list()
      setCameras(res.data)

    } catch (err) {
      console.error(err)
    } finally {
      setAdding(false)
    }
  }

  const activeCams = cameras.filter(c => c.is_active)

  // ✅ Loading UI
  if (loading) {
    return <div style={{ padding: 20 }}>Loading cameras...</div>
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Live Cameras</h1>

      {/* Add camera form */}
      <form onSubmit={addCamera} style={{ marginBottom: 16 }}>
        <input
          placeholder="Camera Name"
          value={form.name}
          onChange={e => setForm({ ...form, name: e.target.value })}
        />
        <input
          placeholder="Source (0, 1, RTSP URL...)"
          value={form.source}
          onChange={e => setForm({ ...form, source: e.target.value })}
        />
        <button type="submit" disabled={adding}>
          {adding ? 'Adding...' : 'Add'}
        </button>
      </form>

      {/* Empty state */}
      {activeCams.length === 0 && (
        <p>No active cameras</p>
      )}

      {/* Camera feeds */}
      {activeCams.map(cam => (
        <CameraFeed
          key={cam.id}
          cameraId={cam.id}
          name={cam.name}
        />
      ))}
    </div>
  )
}